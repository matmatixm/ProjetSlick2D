#!/bin/bash

PWD=$(pwd)
if [ "$BASH_ARGV" == "" ]
then
	temp=$0
else
	temp=$BASH_ARGV
fi

path=${temp%/*}
pathCourt=${path#$PWD}
pathCourt=${pathCourt#/}

cd "$pathCourt"

java -jar -Djava.library.path=libs/natives executable/Lunch.jar & 

killall Terminal

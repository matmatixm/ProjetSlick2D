
########################################################################################################################

Si le jeu ne se lance pas avec Eclipse: 
Erreur : Exception in thread "main" java.lang.UnsatisfiedLinkError: no lwjgl in java.library.path

-Clique droit sur game/Main.java
-Properties
-run/debug settings
-double cliquer sur le main
-Arguments
-entrer la phrase ci dessous dans la case "VM arguments" (sans les "")
	"-Djava.library.path=libs/natives"

########################################################################################################################


A faire :
- Debugguer maMap.tmx
- regarder les tasks.
- En cours les phases de combat


########################################################################################################################

Si apres creation d'une map on a cette erreur : 

Carte : "Failed to parse tilemap at org.newdawn.slick.tiled.TiledMap"

Si vous avez cette erreur quand vous ajouter un calque d'objet, cela viens en fait de votre version de Tiled qui n'enregistre
plus la taille de la carte dans ce calque.  Vous pouvez éditer votre carte avec un éditeur texte, rechercher cette balise :

<objectgroup name="...">

Et ajouter les attributs width et height comme ceci :

<objectgroup name="..." width="XXX" height="YYY">

Ou XXX et YYY est respectivement la largeur et la hauteur de votre carte en tuile.

########################################################################################################################

Futur Infos

########################################################################################################################

package bataille;

import preferences.Preferences;

public class CaracteristiquesCombat {
	// Attributs
	private String nom;
	private String spriteCombat;

	// Caracteristique
	private float vieMax;
	private float vieActuelle;
	private float manaMax;
	private float manaActuelle;

	private int force;
	private int intelligence;

	// Constructeur
	public CaracteristiquesCombat(String nom, float vieMax, float vieActuelle, float manaMax, float manaActuelle,
			int force, int intelligence) {
		super();
		this.nom = nom;
		this.spriteCombat = Preferences.DOSSIER_SPRITES_COMBAT + nom + ".png";
		this.vieMax = vieMax;
		this.vieActuelle = vieActuelle;
		this.manaMax = manaMax;
		this.manaActuelle = manaActuelle;
		this.force = force;
		this.intelligence = intelligence;
	}

	public CaracteristiquesCombat() {
		super();
	}

	public CaracteristiquesCombat(CaracteristiquesCombat cb) {
		super();
		this.nom = cb.getNom();
		this.spriteCombat = cb.getSpriteCombat();
		this.vieMax = cb.getVieMax();
		this.vieActuelle = cb.getVieActuelle();
		this.manaMax = cb.getManaMax();
		this.manaActuelle = cb.getManaActuelle();
		this.force = cb.getForce();
		this.intelligence = cb.getIntelligence();
	}

	// Methodes
	public String toString() {
		String texte = "CaracteristiquesCombat : \n";
		texte += "Nom = " + nom + "\n";
		texte += "SpriteCombat = " + spriteCombat + "\n";
		texte += "Vie Max = " + vieMax + "\n";
		texte += "Vie Actuelle = " + vieActuelle + "\n";
		texte += "Mana Max = " + manaMax + "\n";
		texte += "Mana Actuelle = " + manaActuelle + "\n";
		texte += "Force = " + force + "\n";
		texte += "Intelligence = " + intelligence + "\n";
		return texte;
	}

	// Getters
	public String getNom() {
		return nom;
	}

	public String getSpriteCombat() {
		return spriteCombat;
	}

	public float getVieMax() {
		return vieMax;
	}

	public float getVieActuelle() {
		return vieActuelle;
	}

	public float getManaMax() {
		return manaMax;
	}

	public float getManaActuelle() {
		return manaActuelle;
	}

	public int getForce() {
		return force;
	}

	public int getIntelligence() {
		return intelligence;
	}

	// Setters
	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setSpriteCombat(String spriteCombat) {
		this.spriteCombat = spriteCombat;
	}

	public void setVieMax(float vieMax) {
		this.vieMax = vieMax;
	}

	public void setVieActuelle(float vieActuelle) {
		this.vieActuelle = vieActuelle;
	}

	public void setManaMax(float manaMax) {
		this.manaMax = manaMax;
	}

	public void setManaActuelle(float manaActuelle) {
		this.manaActuelle = manaActuelle;
	}

	public void setForce(int force) {
		this.force = force;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}
}

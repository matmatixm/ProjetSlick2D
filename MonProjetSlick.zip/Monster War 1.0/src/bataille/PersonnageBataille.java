package bataille;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import sauvegarde.Serialiser;

public class PersonnageBataille {
	// Attributs
	private CaracteristiquesCombat caracteristiques;
	private Image sprite;
	private boolean aGauche;
	private Serialiser<CaracteristiquesCombat> saveLoader;

	// Constructeur
	public PersonnageBataille(String nom, float vieMax, float vieActuelle, float manaMax, float manaActuelle, int force,
			int intelligence, boolean aDroite) throws SlickException {

		caracteristiques = new CaracteristiquesCombat(nom, vieMax, vieActuelle, manaMax, manaActuelle, force,
				intelligence);
		this.aGauche = aDroite;
		sprite = new Image(caracteristiques.getSpriteCombat()).getScaledCopy(2);
		saveLoader = new Serialiser<>(nom, caracteristiques);
	}

	public PersonnageBataille(String nom, boolean aDroite) throws SlickException {
		saveLoader = new Serialiser<>(nom, new CaracteristiquesCombat());
		this.aGauche = aDroite;
		this.charger();
		sprite = new Image(caracteristiques.getSpriteCombat()).getScaledCopy(2);
	}

	// Methodes
	public void render(GameContainer container) {
		if (aGauche)
			this.sprite.drawCentered(container.getWidth() * 1 / 4, container.getHeight() / 2);
		else
			this.sprite.drawCentered(container.getWidth() * 3 / 4, container.getHeight() / 2);
	}

	public void sauvegarder() {
		saveLoader.sauvegarder(caracteristiques);
	}

	public void charger() throws SlickException {
		this.caracteristiques = saveLoader.charger();
	}
}

package bidules;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;

public class Camera {
	// Attributs
	private float xCamera;
	private float yCamera;
	private Personnage joueur;

	// Constructeur
	public Camera(Personnage joueur) {
		this.joueur = joueur;
		this.xCamera = joueur.getPosition().getX();
		this.yCamera = joueur.getPosition().getY();
	}

	// Methodes
	public void placer(GameContainer container, Graphics graph) {
		graph.translate(container.getWidth() / 2 - (int) xCamera, container.getHeight() / 2 - (int) yCamera);
	}

	public void update(GameContainer container) {
		int margeLargeur = container.getWidth() / 4;
		int margeHauteur = container.getHeight() / 4;

		if (joueur.getPosition().getX() > this.xCamera + margeLargeur) {
			this.xCamera = joueur.getPosition().getX() - margeLargeur;
		} else if (joueur.getPosition().getX() < this.xCamera - margeLargeur) {
			this.xCamera = joueur.getPosition().getX() + margeLargeur;
		}

		if (joueur.getPosition().getY() > this.yCamera + margeHauteur) {
			this.yCamera = joueur.getPosition().getY() - margeHauteur;
		} else if (joueur.getPosition().getY() < this.yCamera - margeHauteur) {
			this.yCamera = joueur.getPosition().getY() + margeHauteur;
		}

		int min = container.getWidth() / 2;
		int max = container.getWidth() * 32 - container.getWidth() / 2;
		if (this.xCamera < min) {
			this.xCamera = min;
		} else if (this.xCamera > max) {
			this.xCamera = max;
		}

		min = container.getHeight() / 2;
		max = container.getHeight() * 32 - container.getHeight() / 2;
		if (this.yCamera < min) {
			this.yCamera = min;
		} else if (this.yCamera > max) {
			this.yCamera = max;
		}
	}
}
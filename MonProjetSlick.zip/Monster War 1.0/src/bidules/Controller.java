package bidules;

import org.newdawn.slick.Input;
import org.newdawn.slick.KeyListener;
import org.newdawn.slick.MouseListener;

public class Controller implements KeyListener, MouseListener {
	// Attributs
	private Personnage joueur;
	private Input input;

	// Constructeur
	public Controller(Personnage joueur) {
		this.joueur = joueur;
	}

	// Methodes
	public void update() {
		if (input.getControllerCount() > 0) {
			joueur.getDirection().setDx(input.getAxisValue(0, 1));
			joueur.getDirection().setDy(input.getAxisValue(0, 2));
		}
	}

	// Clavier
	public void setInput(Input input) {
		this.input = input;
	}

	public boolean isAcceptingInput() {
		return true;
	}

	public void inputEnded() {
	}

	public void inputStarted() {
	}

	public void keyPressed(int key, char c) {
		// Attention mettre les touches d'un clavier QWERTY meme si on est en AZERTY
		switch (key) {
		case Input.KEY_W:
		case Input.KEY_UP:
			joueur.getDirection().setDy(-1);
			break;
		case Input.KEY_A:
		case Input.KEY_LEFT:
			joueur.getDirection().setDx(-1);
			break;
		case Input.KEY_S:
		case Input.KEY_DOWN:
			joueur.getDirection().setDy(1);
			break;
		case Input.KEY_D:
		case Input.KEY_RIGHT:
			joueur.getDirection().setDx(1);
			break;
		}
	}

	public void keyReleased(int key, char c) {
		switch (key) {
		case Input.KEY_W:
		case Input.KEY_UP:
		case Input.KEY_S:
		case Input.KEY_DOWN:
			joueur.getDirection().setDy(0);
			break;
		case Input.KEY_A:
		case Input.KEY_LEFT:
		case Input.KEY_D:
		case Input.KEY_RIGHT:
			joueur.getDirection().setDx(0);
			break;
		}
	}

	// Souris
	public void mouseClicked(int button, int x, int y, int clickCount) {
		// TODO A ENLEVER : Affiche position souris
		System.out.println("click in (" + x + "," + y + ")");
	}

	public void mouseDragged(int arg0, int arg1, int arg2, int arg3) {
	}

	public void mouseMoved(int arg0, int arg1, int arg2, int arg3) {
	}

	public void mousePressed(int arg0, int arg1, int arg2) {
	}

	public void mouseReleased(int arg0, int arg1, int arg2) {
	}

	public void mouseWheelMoved(int arg0) {
	}
}
package bidules;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import preferences.Preferences;

public class EcranTitre {
	// Attributs
	private Image background;
	private String texte;
	private int diffX;
	private int diffY;

	// Constructeur
	public EcranTitre() throws SlickException {
		background = new Image(Preferences.DOSSIER_BACKGROUNDS + "ecranTitre.png");
		texte = "Appuyer sur une touche pour JOUER";

		// TODO Recuperer le bonnes valeurs pour centre a lecran
		// en fonction de la taille de texte (frontMetrics)
		diffX = 150;
		diffY = 200;
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		background.draw(0, 0, container.getWidth(), container.getHeight());
		graph.drawString(texte, Preferences.FENETRE_WIDTH / 2 - diffX, Preferences.FENETRE_HEIGHT / 2 + diffY);
	}
}

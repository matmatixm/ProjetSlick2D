package bidules;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

public abstract class Personnage {
	// Caracteristique Personnage
	private float vieMax;
	private float vieActuelle;
	private float manaMax;
	private float manaActuelle;
	private float expMax;
	private float expActuelle;
	private float vitesse;

	// Attributs Principaux
	private Map map = null;
	private SpriteSheet spriteSheet;
	private Animation[] animations;

	// Attributs Physiques
	private Position position = null;
	private Position positionGraphique = null;
	private Direction direction = null;
	private boolean onStair = false;

	// Attributs Graphiques
	private int nombreSpriteDeplacement;
	private float diffPosGraphiqueX;
	private float diffPosGraphiqueY;
	private int tailleSpriteX;
	private int tailleSpriteY;
	private int rafraichissementAnimation;

	// Constructeur
	public Personnage(String fileSpriteSheet, Map map) throws SlickException {
		this.map = map;

		// TODO recuperer ces donnees dans un fichier txt
		this.nombreSpriteDeplacement = 8;
		this.diffPosGraphiqueX = 32;
		this.diffPosGraphiqueY = 60;
		this.tailleSpriteX = 64;
		this.tailleSpriteY = 64;
		this.rafraichissementAnimation = 75;

		// recuperer ces donnees dans un fichier txt
		this.vieMax = 100;
		this.vieActuelle = 88;
		this.manaMax = 150;
		this.manaActuelle = 43;
		this.expMax = 1000;
		this.expActuelle = 987;
		this.vitesse = .1f;

		// recuperer ces donnees dans un fichier txt
		changerPosition(new Position(300, 300));
		this.direction = Direction.Bas;

		spriteSheet = new SpriteSheet(fileSpriteSheet, this.tailleSpriteX, this.tailleSpriteY);
		loadAllAnimation();
	}

	// Methodes
	private void loadAllAnimation() {
		animations = new Animation[8];
		this.animations[0] = loadAnimation(spriteSheet, 0, 1, 0);
		this.animations[1] = loadAnimation(spriteSheet, 0, 1, 1);
		this.animations[2] = loadAnimation(spriteSheet, 0, 1, 2);
		this.animations[3] = loadAnimation(spriteSheet, 0, 1, 3);
		this.animations[4] = loadAnimation(spriteSheet, 1, nombreSpriteDeplacement + 1, 0);
		this.animations[5] = loadAnimation(spriteSheet, 1, nombreSpriteDeplacement + 1, 1);
		this.animations[6] = loadAnimation(spriteSheet, 1, nombreSpriteDeplacement + 1, 2);
		this.animations[7] = loadAnimation(spriteSheet, 1, nombreSpriteDeplacement + 1, 3);
	}

	private Animation loadAnimation(SpriteSheet spriteSheet, int startX, int endX, int y) {
		Animation animation = new Animation();
		for (int x = startX; x < endX; x++) {
			animation.addFrame(spriteSheet.getSprite(x, y), rafraichissementAnimation);
		}
		return animation;
	}

	public void render(Graphics graph) {
		graph.drawAnimation(animations[direction.getDirection() + (isMoving() ? 4 : 0)], (int) positionGraphique.getX(),
				(int) positionGraphique.getY());
	}

	public void update(int delta) {
		if (this.isMoving()) {
			updateDirection();
			float futurX = calculFutureX(delta);
			float futurY = calculFuturY(delta);
			if (map.isCollision(futurX, futurY))
				direction.stopMoving();
			else
				changerPosition(new Position(futurX, futurY));
		}
	}

	private void updateDirection() {
		direction.updateDirection();
	}

	private float calculFutureX(int delta) {
		return this.position.getX() + this.vitesse * delta * this.direction.getDx();
	}

	private float calculFuturY(int delta) {
		float futurY = this.position.getY() + this.vitesse * delta * this.direction.getDy();
		if (this.onStair) {
			futurY = futurY - this.vitesse * delta * this.direction.getDx();
		}
		return futurY;
	}

	public void changerPosition(Position newPosition) {
		position = newPosition;
		positionGraphique = new Position(position.getX() - diffPosGraphiqueX, position.getY() - diffPosGraphiqueY);
	}

	public void stopMoving() {
		this.direction.stopMoving();
	}

	// Getters
	public float getVieMax() {
		return vieMax;
	}

	public float getVieActuelle() {
		return vieActuelle;
	}

	public float getManaMax() {
		return manaMax;
	}

	public float getManaActuelle() {
		return manaActuelle;
	}

	public float getExpMax() {
		return expMax;
	}

	public float getExpActuelle() {
		return expActuelle;
	}

	public float getVitesse() {
		return vitesse;
	}

	public Map getMap() {
		return map;
	}

	public SpriteSheet getSpriteSheet() {
		return spriteSheet;
	}

	public Animation[] getAnimations() {
		return animations;
	}

	public Position getPosition() {
		return position;
	}

	public Position getPositionGraphique() {
		return positionGraphique;
	}

	public Direction getDirection() {
		return direction;
	}

	public boolean isMoving() {
		return (direction.getDx() != 0 || direction.getDy() != 0);
	}

	public boolean isOnStair() {
		return onStair;
	}

	public int getNombreSpriteDeplacement() {
		return nombreSpriteDeplacement;
	}

	public float getDiffPosGraphiqueX() {
		return diffPosGraphiqueX;
	}

	public float getDiffPosGraphiqueY() {
		return diffPosGraphiqueY;
	}

	public int getTailleSpriteX() {
		return tailleSpriteX;
	}

	public int getTailleSpriteY() {
		return tailleSpriteY;
	}

	public int getRafraichissementAnimation() {
		return rafraichissementAnimation;
	}

	// Setters
	public void setVieMax(float vieMax) {
		this.vieMax = vieMax;
	}

	public void setVieActuelle(float vieActuelle) {
		this.vieActuelle = vieActuelle;
	}

	public void setManaMax(float manaMax) {
		this.manaMax = manaMax;
	}

	public void setManaActuelle(float manaActuelle) {
		this.manaActuelle = manaActuelle;
	}

	public void setExpMax(float expMax) {
		this.expMax = expMax;
	}

	public void setExpActuelle(float expActuelle) {
		this.expActuelle = expActuelle;
	}

	public void setVitesse(float vitesse) {
		this.vitesse = vitesse;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	public void setSpriteSheet(SpriteSheet spriteSheet) {
		this.spriteSheet = spriteSheet;
	}

	public void setAnimations(Animation[] animations) {
		this.animations = animations;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public void setOnStair(boolean onStair) {
		this.onStair = onStair;
	}

	public void setNombreSpriteDeplacement(int nombreSpriteDeplacement) {
		this.nombreSpriteDeplacement = nombreSpriteDeplacement;
	}

	public void setDiffPosGraphiqueX(float diffPosGraphiqueX) {
		this.diffPosGraphiqueX = diffPosGraphiqueX;
	}

	public void setDiffPosGraphiqueY(float diffPosGraphiqueY) {
		this.diffPosGraphiqueY = diffPosGraphiqueY;
	}

	public void setTailleSpriteX(int tailleSpriteX) {
		this.tailleSpriteX = tailleSpriteX;
	}

	public void setTailleSpriteY(int tailleSpriteY) {
		this.tailleSpriteY = tailleSpriteY;
	}

	public void setRafraichissementAnimation(int rafraichissementAnimation) {
		this.rafraichissementAnimation = rafraichissementAnimation;
	}
}
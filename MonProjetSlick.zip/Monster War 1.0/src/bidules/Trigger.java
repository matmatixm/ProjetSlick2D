package bidules;

import org.newdawn.slick.SlickException;

public class Trigger {
	// Attributs
	private Map map;
	private Personnage joueur;

	// Constructeur
	public Trigger(Map map, Personnage joueur) {
		this.map = map;
		this.joueur = joueur;
	}

	public void update() throws SlickException {
		this.joueur.setOnStair(false);
		for (int objectID = 0; objectID < this.map.getObjectCount(); objectID++) {
			if (PlayerIsInTrigger(objectID)) {
				if ("teleport".equals(this.map.getObjectType(objectID))) {
					this.teleport(objectID);
				} else if ("stair".equals(this.map.getObjectType(objectID))) {
					this.joueur.setOnStair(true);
				} else if ("change-map".equals(this.map.getObjectType(objectID))) {
					this.changeMap(objectID);
				}
			}
		}
	}

	private boolean PlayerIsInTrigger(int id) {
		return this.joueur.getPosition().getX() > this.map.getObjectX(id)
				&& this.joueur.getPosition().getX() < this.map.getObjectX(id) + this.map.getObjectWidth(id)
				&& this.joueur.getPosition().getY() > this.map.getObjectY(id)
				&& this.joueur.getPosition().getY() < this.map.getObjectY(id) + this.map.getObjectHeight(id);
	}

	private void teleport(int objectID) {
		float x = (Float.parseFloat(
				this.map.getObjectProperty(objectID, "dest-x", Float.toString(this.joueur.getPosition().getX()))));
		float y = (Float.parseFloat(
				this.map.getObjectProperty(objectID, "dest-y", Float.toString(this.joueur.getPosition().getY()))));
		this.joueur.changerPosition(new Position(x, y));
	}

	private void changeMap(int objectID) throws SlickException {
		this.teleport(objectID);
		String newMap = this.map.getObjectProperty(objectID, "dest-map", "undefined");
		if (!"undefined".equals(newMap)) {
			this.map.changeMap("maps/" + newMap);
		}
	}
}
package main;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;

import preferences.Preferences;
import statesGame.StateGame;

public class Main {

	public static void main(String[] args) throws SlickException {
		new AppGameContainer(new StateGame(), Preferences.FENETRE_WIDTH, Preferences.FENETRE_HEIGHT, false).start();
	}
}

package preferences;

import java.awt.GraphicsEnvironment;

public abstract class Preferences {
	// Fenetre
	public static final String NOM_JEU = "Monster War";
	public static final String LIEN_ICONE_FENETRE = "./MonsterWarIcon.png";

	// Liste Dossiers
	public static final String DOSSIER_SPRITES_MAP = "./sprites/";
	public static final String DOSSIER_SPRITES_COMBAT = "./spritesCombat/";
	public static final String DOSSIER_SOUNDS = "./sounds/";
	public static final String DOSSIER_MAPS = "./maps/";
	public static final String DOSSIER_SAUVEGARDES = "./sauvegardes/";
	public static final String DOSSIER_LIBRAIRIES = "./libs/";
	public static final String DOSSIER_BACKGROUNDS = "./backgrounds/";
	public static final String DOSSIER_HUDS = "./huds/";

	// Liste Fichier Affichage
	public static final String FICHIER_HUD = DOSSIER_HUDS + "barre.png";
	public static final String MAP_START = DOSSIER_MAPS + "route1.tmx";
	public static final String BACKGROUND_BATTLE = DOSSIER_BACKGROUNDS + "battle.png";

	// Noms Calques
	public static final String CALQUE_LOGIC = "logic";

	// Liste Fichier Music
	public static final String MUSIQUE_FOND = DOSSIER_SOUNDS + "lost-in-the-meadows.ogg";

	// TailleFenetre
	public final static int FENETRE_WIDTH = (int) GraphicsEnvironment.getLocalGraphicsEnvironment()
			.getMaximumWindowBounds().getWidth() - 50;
	public final static int FENETRE_HEIGHT = (int) GraphicsEnvironment.getLocalGraphicsEnvironment()
			.getMaximumWindowBounds().getHeight() - 50;

}

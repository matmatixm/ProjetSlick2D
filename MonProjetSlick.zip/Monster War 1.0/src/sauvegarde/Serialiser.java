package sauvegarde;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import preferences.Preferences;

public class Serialiser<T> {
	// Attributs
	private T maClasse;
	private String nomFichier;

	public Serialiser(String nomObjet, T maClasse) {
		this.maClasse = maClasse;
		String nomClasse = maClasse.getClass().getName();
		nomClasse = nomClasse.substring(nomClasse.lastIndexOf('.') + 1);
		nomFichier = Preferences.DOSSIER_SAUVEGARDES + nomClasse + "/" + nomClasse + "-" + nomObjet;
	}

	public void sauvegarder(T monObjet) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			mapper.writeValue(new File(nomFichier), monObjet);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public T charger() {
		try {
			ObjectMapper mapper = new ObjectMapper();
			T monObjet = (T) mapper.readValue(new File(nomFichier), maClasse.getClass());
			return monObjet;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
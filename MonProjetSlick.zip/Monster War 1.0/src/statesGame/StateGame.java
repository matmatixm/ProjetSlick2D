package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

import preferences.Preferences;

public class StateGame extends StateBasedGame {

	public StateGame() {
		super(Preferences.NOM_JEU);
	}

	public void initStatesList(GameContainer container) throws SlickException {
		container.setIcon(Preferences.LIEN_ICONE_FENETRE);
		container.setShowFPS(false);
		
		addState(new TitleScreenGameState());
		addState(new MainGameState());
		addState(new BattleGameState());
	}
}

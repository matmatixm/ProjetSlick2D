package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

import bidules.EcranTitre;

public class TitleScreenGameState extends BasicGameState {
	// Attributs
	public static final int ID = 0;
	private StateBasedGame game;
	private EcranTitre ecranTitre;

	// Constructeur
	public TitleScreenGameState() {
		super();
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.game = game;
		this.ecranTitre = new EcranTitre();

	}

	public void render(GameContainer container, StateBasedGame game, Graphics graph) throws SlickException {
		ecranTitre.render(container, graph);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
	}

	// Methodes
	public int getID() {
		return ID;
	}

	public void keyReleased(int key, char c) {
		game.enterState(MainGameState.ID);
	}
}

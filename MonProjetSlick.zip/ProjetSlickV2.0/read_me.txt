
########################################################################################################################

Si le jeu ne se lance pas :

-Clique droit sur game/Main.java
-Properties
-run/debug settings
-double cliquer sur le main
-Arguments
-entrer la phrase ci dessous dans la case "VM arguments" (sans les "")
	"-Djava.library.path=libs/natives"

########################################################################################################################


A faire :

- regarder les tasks.
- gerer le packaging (lecon 8 : http://www.shionn.org/lesson-8-jar-execute-slick)
- En cours le HUD (13)


########################################################################################################################


A essayer pour tamuser : 
- rentrer dans les grottes sur la droite.
- prendre le pont en bas de la map puis a droite puis tomber dans le trou.
- une fois dans la nouvelle map aller a droite puis un peu en bas et marcher devant le gros rocher juste devant le visage.

########################################################################################################################

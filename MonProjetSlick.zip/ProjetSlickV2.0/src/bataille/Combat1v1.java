package bataille;

public class Combat1v1 {
	//Attributs
	private PersonnageBataille gauche;
	private PersonnageBataille droit;
	

}

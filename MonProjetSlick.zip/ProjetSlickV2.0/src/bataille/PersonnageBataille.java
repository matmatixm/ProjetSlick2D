package bataille;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class PersonnageBataille {
	// Attributs
	private float vieMax;
	private float vieActuelle;
	private float manaMax;
	private float manaActuelle;

	// Caracteristique
	private int force;
	private int intelligence;

	// Affichage
	private Image sprite;
	private boolean gentil;

	// Constructeur
	// TODO enlever gentil quand fichier txt
	public PersonnageBataille(float vieMax, float vieActuelle, float manaMax, float manaActuelle, int force,
			int intelligence, boolean gentil) throws SlickException {
		this.vieMax = vieMax;
		this.vieActuelle = vieActuelle;
		this.manaMax = manaMax;
		this.manaActuelle = manaActuelle;
		this.force = force;
		this.intelligence = intelligence;
		this.gentil = gentil;

		if (gentil)
			sprite = new Image("battles/hero.png").getScaledCopy(2);
		else
			sprite = new Image("battles/gobelin.png").getScaledCopy(2);
	}

	public void render(GameContainer container) {
		if (gentil)
			this.sprite.drawCentered(container.getWidth() * 1 / 4, container.getHeight() / 2);
		else
			this.sprite.drawCentered(container.getWidth() * 3 / 4, container.getHeight() / 2);
	}
}

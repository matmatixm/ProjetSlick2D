package bidules;

public enum Direction {
	Haut(0), Gauche(1), Bas(2), Droite(3);

	// Attributs
	private int direction;
	private float dx;
	private float dy;

	// Constructeur
	private Direction(int direction) {
		this.direction = direction;
	}

	// Methodes
	public void setVecteur(float dx, float dy) {
		this.dx = dx;
		this.dy = dy;
	}

	public void updateDirection() {
		if (dx > 0 && dx >= Math.abs(dy)) {
			direction = 3;
		} else if (dx < 0 && -dx >= Math.abs(dy)) {
			direction = 1;
		} else if (dy < 0) {
			direction = 0;
		} else {
			direction = 2;
		}
	}

	public void stopMoving() {
		this.dx = 0;
		this.dy = 0;
	}

	// Getters
	public float getDx() {
		return dx;
	}

	public float getDy() {
		return dy;
	}

	public int getDirection() {
		return this.direction;
	}

	public Direction getEnumDirection(int num) {
		return Direction.values()[num];
	}

	// Setters
	public void setDx(float dx) {
		this.dx = dx;
	}

	public void setDy(float dy) {
		this.dy = dy;
	}
}

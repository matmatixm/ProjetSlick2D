package bidules;

import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;

import preferences.Preferences;

public class Hero extends Personnage {
	// Constructeur
	public Hero(Map map) throws SlickException {
		super(Preferences.spriteHero, map);
	}

	// Methodes
	@Override
	public void render(Graphics graph) {
		super.render(graph);
		
		// Affichage d'une ombre
		graph.setColor(new Color(0, 0, 0, .5f));
		graph.fillOval(getPosition().getX() - 16, (int) getPosition().getY() - 8, 32, 16);
	}
}
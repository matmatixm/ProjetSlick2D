package bidules;

public class Position {
	// Attributs
	private float x;
	private float y;

	// Constructeur
	public Position(float x, float y) {
		this.x = x;
		this.y = y;
	}

	// Getters
	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}
}
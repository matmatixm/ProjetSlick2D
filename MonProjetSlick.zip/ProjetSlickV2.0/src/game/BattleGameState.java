package game;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

import bataille.PersonnageBataille;

public class BattleGameState extends BasicGameState {
	// Attributs
	public static final int ID = 2;
	private StateBasedGame game;
	private Image background;
	private PersonnageBataille ennemy;
	private PersonnageBataille hero;

	// Constructeur
	public BattleGameState() {
		super();
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.game = game;
		this.background = new Image("backgrounds/battle.png");
		this.hero = new PersonnageBataille(100, 100, 150, 150, 75, 100, true);
		this.ennemy = new PersonnageBataille(20, 20, 0, 0, 10, 0, false);
	}

	public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException {
		background.draw(0, 0, container.getWidth(), container.getHeight());
		ennemy.render(container);
		hero.render(container);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
	}

	// Methodes
	public void keyPressed(int key, char c) {
		game.enterState(MainGameState.ID);
	}

	public int getID() {
		return ID;
	}
}
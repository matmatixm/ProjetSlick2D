package game;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Music;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

import bidules.Camera;
import bidules.Controller;
import bidules.Hero;
import bidules.Hud;
import bidules.Map;
import bidules.Trigger;
import preferences.Preferences;

public class MainGameState extends BasicGameState {

	// Attributs
	public static final int ID = 1;
	private GameContainer container;
	private Map map;
	private Hero hero;
	private Hud hud;
	private Camera camera;
	private Music backgroundMusic;
	private Trigger triggers;
	private Controller controler;

	// Constructeur
	public MainGameState() {
		super();
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.container = container;
		this.container.setShowFPS(false);

		this.backgroundMusic = new Music(Preferences.musiqueBackground);
		this.backgroundMusic.loop();

		this.map = new Map();
		this.hero = new Hero(map);
		this.hud = new Hud(hero);
		this.triggers = new Trigger(map, hero);
		this.camera = new Camera(hero);

		this.controler = new Controller(hero);
		this.controler.setInput(container.getInput());
		this.container.getInput().addKeyListener(controler);
		this.container.getInput().addMouseListener(controler);
	}

	public void render(GameContainer container, StateBasedGame game, Graphics graph) throws SlickException {
		this.camera.placer(container, graph);
		this.map.renderBackground();
		this.hero.render(graph);
		this.map.renderForeground();
		this.hud.render(graph);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
		this.controler.update();
		this.triggers.update();
		this.hero.update(delta);
		this.camera.update(container);
		if (Math.random() < 0.001 && hero.isMoving()) {
			game.enterState(BattleGameState.ID);
		}
	}

	// Methode
	public int getID() {
		return ID;
	}
}
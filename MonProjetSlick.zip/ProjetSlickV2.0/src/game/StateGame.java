package game;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

public class StateGame extends StateBasedGame {

	public StateGame() {
		super("Putain de jeu trop stylé de la mort qui tue !!!");
	}

	public void initStatesList(GameContainer container) throws SlickException {
		addState(new TitleScreenGameState());
		addState(new MainGameState());
		addState(new BattleGameState());
	}
}

package preferences;

import java.awt.GraphicsEnvironment;

public abstract class Preferences {
	// Chemins utiles
	public static final String MAP_INIT = "./maps/exemple-change-map.tmx";
	public static final String Image_Background = "./backgrounds/forest.png";

	// Chemin fichiers
	public static final String fichierLevelStarting = "./maps/exemple-change-map.tmx";
	public static final String spriteHero = "./sprites/hero.png";
	public static final String musiqueBackground = "./sounds/lost-in-the-meadows.ogg";
	public static final String imageHUD = "./huds/player-bar.png";

	// TailleFenetre
	public final static int FENETRE_WIDTH = (int) GraphicsEnvironment.getLocalGraphicsEnvironment()
			.getMaximumWindowBounds().getWidth() - 50;
	public final static int FENETRE_HEIGHT = (int) GraphicsEnvironment.getLocalGraphicsEnvironment()
			.getMaximumWindowBounds().getHeight() - 50;

}

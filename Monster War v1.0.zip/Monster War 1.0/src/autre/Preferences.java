package autre;

import java.awt.GraphicsEnvironment;

import ecranMap.Position;

public abstract class Preferences {
	// Liste Dossiers
	public static final String DOSSIER_SPRITES_MAP = "./sprites/";
	public static final String DOSSIER_SPRITES_COMBAT = "./spritesCombat/";
	public static final String DOSSIER_SOUNDS = "./sounds/";
	public static final String DOSSIER_MAPS = "./maps/";
	public static final String DOSSIER_SAUVEGARDES = "./sauvegardes/";
	public static final String DOSSIER_LIBRAIRIES = "./libs/";
	public static final String DOSSIER_BACKGROUNDS = "./backgrounds/";
	public static final String DOSSIER_HUDS = "./huds/";

	// Fenetre
	public static final String NOM_JEU = "Monster War";
	public static final String LIEN_ICONE_FENETRE = DOSSIER_HUDS + "monsterWarIcon.png";

	// Creation Personnage
	public static final Position POSITION_DEPART = new Position(300, 300);
	public static final String MAP_DEPART = DOSSIER_MAPS + "route1.tmx";

	// Timers
	public static final int TIME_CLICK_BUTTON = 50;

	// Noms Calques
	public static final String CALQUE_LOGIC = "logic";

	// Liste Fichier Music
	public static final String MUSIQUE_FOND = DOSSIER_SOUNDS + "lost-in-the-meadows.ogg";

	// ID Differentes Fenetre
	public static final int FENETRE_ECRAN_TITRE = 0;
	public static final int FENETRE_CREATION_CHARGEMENT_COMPTE = 1;
	public static final int FENETRE_MAP = 2;
	public static final int FENETRE_COMBAT = 3;

	// TailleFenetre
	public final static int FENETRE_WIDTH = (int) GraphicsEnvironment.getLocalGraphicsEnvironment()
			.getMaximumWindowBounds().getWidth() - 50;
	public final static int FENETRE_HEIGHT = (int) GraphicsEnvironment.getLocalGraphicsEnvironment()
			.getMaximumWindowBounds().getHeight() - 50;

}

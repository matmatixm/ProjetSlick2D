package ecranCreationSelectionCompte;

import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import autre.Preferences;
import ecranMap.Personnage;

public class CreationPersonnage {
	// Infos Block
	private float x;
	private float y;
	private float width;
	private float height;

	// Objets
	private Image background;
	private Font font;
	private boolean creationReussi = false;

	// Layers
	private ZoneSaisieTexte saisiePseudo;
	private SelectionSprite selectSprite;
	private SelectionStats selectStates;
	private ValidationCreation valideCreation;

	// Constructeur
	public CreationPersonnage(GameContainer gc) throws SlickException {
		// TODO affectation des tailles a faire
		// Recuperer les coordonnes du parchemin qqsoit la taille de la Fenetre
		this.x = 680;
		this.y = 180;
		this.width = 550;
		this.height = 600;

		// TODO Creer une fonte en fonction de la fenetre
		this.font = gc.getDefaultFont();
		// TAILLE = fonction de la police
		// POLICE = a voir
		// COULEUR = new Color(0, 160, 180);
		// ou COULEUR = new Color(3, 39, 102);
		// Ecriture Grasse suivant la polie

		// Differentes auteur des layers
		float height1 = height * 0.2f;
		float heightEspace1 = height * 0.05f;
		float height2 = height * 0.3f;
		float heightEspace2 = height * 0.0f;
		float height3 = height * 0.45f;

		// Position et tailles
		float xVC = x * 1.47059f;
		float yVC = y * 4.77778f;
		float widthVC = width * 0.272727f;
		float heightVC = height * 0.125f;

		// Creation des layers
		background = new Image(Preferences.DOSSIER_BACKGROUNDS + "creationCompte.png");
		saisiePseudo = new ZoneSaisieTexte(x, y, width, height1, font, gc);
		selectSprite = new SelectionSprite(x, y + height1 + heightEspace1, width, height2, gc);
		selectStates = new SelectionStats(x, y + height1 + heightEspace1 + height2 + heightEspace2, width, height3,
				font, gc);
		valideCreation = new ValidationCreation(this, xVC, yVC, widthVC, heightVC, gc);
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		background.draw(0, 0, container.getWidth(), container.getHeight());
		saisiePseudo.render(container, graph);
		selectSprite.render(container, graph);
		selectStates.render(container, graph);
		valideCreation.render(container, graph);
	}

	public void update(int delta) {
		saisiePseudo.update(delta);
		selectSprite.update(delta);
		selectStates.update(delta);
		valideCreation.update(delta);
	}

	public void updateClick(int x, int y) {
		saisiePseudo.updateClick(x, y);
		selectSprite.updateClick(x, y);
		selectStates.updateClick(x, y);
		valideCreation.updateClick(x, y);
	}

	public void valider() {
		String pseudo = saisiePseudo.recuperationNom();
		if (!pseudo.equals("") && !pseudo.equals("    Pseudo") && selectStates.getNbrePointsTotal() == 0) {
			Personnage p = new Personnage();
			p.newPersonnage(pseudo, selectSprite.recuperationSprite(), selectStates.recuperationForce(),
					selectStates.recuperationIntel(), selectStates.recuperationConst(),
					selectStates.recuperationEsprit(), selectStates.recuperationAgi());
			creationReussi = true;
		}
	}

	// Getters
	public boolean isCreationReussi() {
		return creationReussi;
	}
}

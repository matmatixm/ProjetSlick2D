package ecranMap;

public class CaracteristiquesMouvement {
	// Attributs Physiques
	private Position position;
	private float diffPosGraphiqueX;
	private float diffPosGraphiqueY;
	private Position positionGraphique;
	private float vitesseDeplacement;
	private Direction direction;
	private boolean onStair;

	// Attributs Graphiques
	private int numSpriteSheet;
	private int nombreSpriteDeplacement;
	private int tailleSpriteX;
	private int tailleSpriteY;
	private int rafraichissementAnimation;

	// Constructeur
	public CaracteristiquesMouvement() {
		super();
	}

	public CaracteristiquesMouvement(Position position, float diffPosGraphiqueX, float diffPosGraphiqueY,
			float vitesseDeplacement, Direction direction, boolean onStair, int numSpriteSheet,
			int nombreSpriteDeplacement, int tailleSpriteX, int tailleSpriteY, int rafraichissementAnimation) {
		super();
		this.position = position;
		this.diffPosGraphiqueX = diffPosGraphiqueX;
		this.diffPosGraphiqueY = diffPosGraphiqueY;
		this.positionGraphique = new Position(position.getX() + diffPosGraphiqueX, position.getY() + diffPosGraphiqueY);
		this.vitesseDeplacement = vitesseDeplacement;
		this.direction = direction;
		this.onStair = onStair;
		this.numSpriteSheet = numSpriteSheet;
		this.nombreSpriteDeplacement = nombreSpriteDeplacement;
		this.tailleSpriteX = tailleSpriteX;
		this.tailleSpriteY = tailleSpriteY;
		this.rafraichissementAnimation = rafraichissementAnimation;
	}

	// Getters
	public int getNumSpriteSheet() {
		return numSpriteSheet;
	}

	public Position getPosition() {
		return position;
	}

	public float getDiffPosGraphiqueX() {
		return diffPosGraphiqueX;
	}

	public float getDiffPosGraphiqueY() {
		return diffPosGraphiqueY;
	}

	public Position getPositionGraphique() {
		return positionGraphique;
	}

	public float getVitesseDeplacement() {
		return vitesseDeplacement;
	}

	public Direction getDirection() {
		return direction;
	}

	public boolean isOnStair() {
		return onStair;
	}

	public int getNombreSpriteDeplacement() {
		return nombreSpriteDeplacement;
	}

	public int getTailleSpriteX() {
		return tailleSpriteX;
	}

	public int getTailleSpriteY() {
		return tailleSpriteY;
	}

	public int getRafraichissementAnimation() {
		return rafraichissementAnimation;
	}

	// Setters
	public void setNumSpriteSheet(int nomSpriteSheet) {
		this.numSpriteSheet = nomSpriteSheet;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public void setDiffPosGraphiqueX(float diffPosGraphiqueX) {
		this.diffPosGraphiqueX = diffPosGraphiqueX;
	}

	public void setDiffPosGraphiqueY(float diffPosGraphiqueY) {
		this.diffPosGraphiqueY = diffPosGraphiqueY;
	}

	public void setPositionGraphique(Position positionGraphique) {
		this.positionGraphique = positionGraphique;
	}

	public void setVitesseDeplacement(float vitesseDeplacement) {
		this.vitesseDeplacement = vitesseDeplacement;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public void setOnStair(boolean onStair) {
		this.onStair = onStair;
	}

	public void setNombreSpriteDeplacement(int nombreSpriteDeplacement) {
		this.nombreSpriteDeplacement = nombreSpriteDeplacement;
	}

	public void setTailleSpriteX(int tailleSpriteX) {
		this.tailleSpriteX = tailleSpriteX;
	}

	public void setTailleSpriteY(int tailleSpriteY) {
		this.tailleSpriteY = tailleSpriteY;
	}

	public void setRafraichissementAnimation(int rafraichissementAnimation) {
		this.rafraichissementAnimation = rafraichissementAnimation;
	}
}

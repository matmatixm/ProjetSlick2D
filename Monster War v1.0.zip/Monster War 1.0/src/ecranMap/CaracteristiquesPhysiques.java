package ecranMap;

public class CaracteristiquesPhysiques {
	// Caracteristique Personnage HUD
	private float vieMax;
	private float vieActuelle;
	private float manaMax;
	private float manaActuelle;
	private float expMax;
	private float expActuelle;

	// Caracteristique Personnage stats
	private float force; 		// Attaque
	private float intelligence; // Magie
	private float constitution; // Defense
	private float esprit; 		// Defense Magique
	private float agilite;		// Esquive
	private float block; 		// Blocage
	private float precision; 	// Precision
	private float chance;		// Coups Critiques
	private float recovery; 	// Recuperation
	private float speed; 		// Vitesse Tour

	// Constructeur
	public CaracteristiquesPhysiques() {
		super();
	}

	public CaracteristiquesPhysiques(float vieMax, float vieActuelle, float manaMax, float manaActuelle, float expMax,
			float expActuelle, float force, float intelligence, float constitution, float esprit, float agilite,
			float block, float precision, float chance, float recovery, float speed) {
		super();
		this.vieMax = vieMax;
		this.vieActuelle = vieActuelle;
		this.manaMax = manaMax;
		this.manaActuelle = manaActuelle;
		this.expMax = expMax;
		this.expActuelle = expActuelle;
		this.force = force;
		this.intelligence = intelligence;
		this.constitution = constitution;
		this.esprit = esprit;
		this.agilite = agilite;
		this.block = block;
		this.precision = precision;
		this.chance = chance;
		this.recovery = recovery;
		this.speed = speed;
	}

	// Getters
	public float getVieMax() {
		return vieMax;
	}

	public float getVieActuelle() {
		return vieActuelle;
	}

	public float getManaMax() {
		return manaMax;
	}

	public float getManaActuelle() {
		return manaActuelle;
	}

	public float getExpMax() {
		return expMax;
	}

	public float getExpActuelle() {
		return expActuelle;
	}

	public float getForce() {
		return force;
	}

	public float getIntelligence() {
		return intelligence;
	}

	public float getConstitution() {
		return constitution;
	}

	public float getEsprit() {
		return esprit;
	}

	public float getAgilite() {
		return agilite;
	}

	public float getBlock() {
		return block;
	}

	public float getPrecision() {
		return precision;
	}

	public float getChance() {
		return chance;
	}

	public float getRecovery() {
		return recovery;
	}

	public float getSpeed() {
		return speed;
	}

	// Setters
	public void setVieMax(float vieMax) {
		this.vieMax = vieMax;
	}

	public void setVieActuelle(float vieActuelle) {
		this.vieActuelle = vieActuelle;
	}

	public void setManaMax(float manaMax) {
		this.manaMax = manaMax;
	}

	public void setManaActuelle(float manaActuelle) {
		this.manaActuelle = manaActuelle;
	}

	public void setExpMax(float expMax) {
		this.expMax = expMax;
	}

	public void setExpActuelle(float expActuelle) {
		this.expActuelle = expActuelle;
	}

	public void setForce(float force) {
		this.force = force;
	}

	public void setIntelligence(float intelligence) {
		this.intelligence = intelligence;
	}

	public void setConstitution(float constitution) {
		this.constitution = constitution;
	}

	public void setEsprit(float esprit) {
		this.esprit = esprit;
	}

	public void setAgilite(float agilite) {
		this.agilite = agilite;
	}

	public void setBlock(float block) {
		this.block = block;
	}

	public void setPrecision(float precision) {
		this.precision = precision;
	}

	public void setChance(float chance) {
		this.chance = chance;
	}

	public void setRecovery(float recovery) {
		this.recovery = recovery;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}
}

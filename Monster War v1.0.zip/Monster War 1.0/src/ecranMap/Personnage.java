package ecranMap;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

import com.fasterxml.jackson.annotation.JsonIgnore;

import autre.Preferences;
import autre.Serialiser;

public class Personnage {
	// Attributs
	private String nom;
	private CaracteristiquesPhysiques stats;
	private CaracteristiquesMouvement statsMap;
	private Map map;
	@JsonIgnore
	private Serialiser<Personnage> saveLoader;
	@JsonIgnore
	private SpriteSheet spriteSheet;
	@JsonIgnore
	private Animation[] animations;

	// Constructeur
	public Personnage() {
		super();
	}

	public Personnage(String nom, CaracteristiquesPhysiques stats, CaracteristiquesMouvement statsMap, Map map)
			throws SlickException {
		super();
		this.nom = nom;
		this.stats = stats;
		this.statsMap = statsMap;
		this.map = map;

		this.saveLoader = new Serialiser<>(nom, this);

		this.spriteSheet = new SpriteSheet(
				Preferences.DOSSIER_SPRITES_MAP + "sprite" + statsMap.getNumSpriteSheet() + ".png",
				statsMap.getTailleSpriteX(), statsMap.getTailleSpriteY());
		loadAllAnimation();

	}

	// Methodes
	public void render(Graphics graph) {
		graph.drawAnimation(animations[statsMap.getDirection().getDirection() + (isMoving() ? 4 : 0)],
				(int) statsMap.getPositionGraphique().getX(), (int) statsMap.getPositionGraphique().getY());
	}

	public void update(int delta) {
		if (this.isMoving()) {
			updateDirection();
			float futurX = calculFutureX(delta);
			float futurY = calculFuturY(delta);
			if (map.isCollision(futurX, futurY))
				statsMap.getDirection().stopMoving();
			else
				changerPosition(new Position(futurX, futurY));
		}
	}

	public void changerPosition(Position newPosition) {
		statsMap.setPosition(newPosition);
		statsMap.setPositionGraphique(new Position(statsMap.getPosition().getX() - statsMap.getDiffPosGraphiqueX(),
				statsMap.getPosition().getY() - statsMap.getDiffPosGraphiqueY()));
	}

	public void newPersonnage(String pseudo, int recuperationSprite, int recuperationForce, int recuperationIntel,
			int recuperationConst, int recuperationEsprit, int recuperationAgi) {
		this.nom = pseudo;
		this.stats = new CaracteristiquesPhysiques(100, 100, 100, 100, 1000, 0, recuperationForce, recuperationIntel,
				recuperationConst, recuperationEsprit, recuperationAgi, 0, 0, 0, 0, 0);
		this.statsMap = new CaracteristiquesMouvement(Preferences.POSITION_DEPART, 32, 60, 0.1f, Direction.Bas, false,
				recuperationSprite, 8, 64, 64, 50);
		this.saveLoader = new Serialiser<>(pseudo, this);
		this.map = new Map(Preferences.MAP_DEPART);
		try {
			this.spriteSheet = new SpriteSheet(Preferences.DOSSIER_SPRITES_MAP + "sprite" + recuperationSprite + ".png",
					64, 64);
		} catch (SlickException e) {
			e.printStackTrace();
		}
		loadAllAnimation();
		this.saveLoader.sauvegarder(this);
	}

	public void newPersonnageRandom() {
		this.nom = "Random";
		this.stats = new CaracteristiquesPhysiques(1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		this.statsMap = new CaracteristiquesMouvement(Preferences.POSITION_DEPART, 32, 60, 0.1f, Direction.Bas, false,
				0, 8, 64, 64, 50);
		this.saveLoader = new Serialiser<>(this.nom, this);
		this.map = new Map(Preferences.MAP_DEPART);
		try {
			this.spriteSheet = new SpriteSheet(Preferences.DOSSIER_SPRITES_MAP + "sprite0.png", 64, 64);
		} catch (SlickException e) {
			e.printStackTrace();
		}
		loadAllAnimation();
	}

	private void loadAllAnimation() {
		animations = new Animation[8];
		this.animations[0] = loadAnimation(spriteSheet, 0, 1, 0);
		this.animations[1] = loadAnimation(spriteSheet, 0, 1, 1);
		this.animations[2] = loadAnimation(spriteSheet, 0, 1, 2);
		this.animations[3] = loadAnimation(spriteSheet, 0, 1, 3);
		this.animations[4] = loadAnimation(spriteSheet, 1, statsMap.getNombreSpriteDeplacement() + 1, 0);
		this.animations[5] = loadAnimation(spriteSheet, 1, statsMap.getNombreSpriteDeplacement() + 1, 1);
		this.animations[6] = loadAnimation(spriteSheet, 1, statsMap.getNombreSpriteDeplacement() + 1, 2);
		this.animations[7] = loadAnimation(spriteSheet, 1, statsMap.getNombreSpriteDeplacement() + 1, 3);
	}

	private Animation loadAnimation(SpriteSheet spriteSheet, int startX, int endX, int y) {
		Animation animation = new Animation();
		for (int x = startX; x < endX; x++) {
			animation.addFrame(spriteSheet.getSprite(x, y), statsMap.getRafraichissementAnimation());
		}
		return animation;
	}

	private void updateDirection() {
		statsMap.getDirection().updateDirection();
	}

	private float calculFutureX(int delta) {
		return statsMap.getPosition().getX()
				+ statsMap.getVitesseDeplacement() * delta * statsMap.getDirection().getDx();
	}

	private float calculFuturY(int delta) {
		float futurY = statsMap.getPosition().getY()
				+ statsMap.getVitesseDeplacement() * delta * statsMap.getDirection().getDy();
		if (statsMap.isOnStair()) {
			futurY = futurY - statsMap.getVitesseDeplacement() * delta * statsMap.getDirection().getDx();
		}
		return futurY;
	}

	// Getters
	public CaracteristiquesPhysiques getStats() {
		return stats;
	}

	public CaracteristiquesMouvement getStatsMap() {
		return statsMap;
	}

	public Serialiser<Personnage> getSaveLoader() {
		return saveLoader;
	}

	public Map getMap() {
		return map;
	}

	public SpriteSheet getSpriteSheet() {
		return spriteSheet;
	}

	public Animation[] getAnimations() {
		return animations;
	}

	public boolean isMoving() {
		return (statsMap.getDirection().getDx() != 0 || statsMap.getDirection().getDy() != 0);
	}

	public Position getPosition() {
		return statsMap.getPosition();
	}

	public float getVieMax() {
		return stats.getVieMax();
	}

	public float getVieActuelle() {
		return stats.getVieActuelle();
	}

	public float getManaMax() {
		return stats.getManaMax();
	}

	public float getManaActuelle() {
		return stats.getManaActuelle();
	}

	public float getExpMax() {
		return stats.getExpMax();
	}

	public float getExpActuelle() {
		return stats.getExpActuelle();
	}

	public Direction getDirection() {
		return statsMap.getDirection();
	}

	public String getNom() {
		return nom;
	}

	// Setters
	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setStats(CaracteristiquesPhysiques stats) {
		this.stats = stats;
	}

	public void setStatsMap(CaracteristiquesMouvement statsMap) {
		this.statsMap = statsMap;
	}

	public void setSaveLoader(Serialiser<Personnage> saveLoader) {
		this.saveLoader = saveLoader;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	public void setSpriteSheet(SpriteSheet spriteSheet) {
		this.spriteSheet = spriteSheet;
	}

	public void setAnimations(Animation[] animations) {
		this.animations = animations;
	}

	public void stopMoving() {
		statsMap.getDirection().stopMoving();
	}

	public void setOnStair(boolean b) {
		statsMap.setOnStair(b);
	}
}
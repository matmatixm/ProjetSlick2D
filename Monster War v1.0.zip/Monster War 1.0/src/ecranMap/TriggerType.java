package ecranMap;

public enum TriggerType {
	// TODO gerer les differents Triggers de la classe Trigger
	Teleporter("teleport"), Escalier("stair"), ChangerMap("change-map");

	// Attributs
	private String commande;

	// Constructeur
	TriggerType(String commande) {
		this.commande = commande;
	}

	// Getters
	public String getCommande() {
		return commande;
	}
}

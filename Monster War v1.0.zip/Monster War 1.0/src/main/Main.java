package main;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;

import autre.Preferences;
import statesGame.StateGame;

public class Main {

	public static void main(String[] args) throws SlickException {
		if (Preferences.FENETRE_WIDTH < 500 || Preferences.FENETRE_HEIGHT < 400) {
			System.out.println("Resolution trop faible");
			System.exit(0);
		}
		new AppGameContainer(new StateGame(), Preferences.FENETRE_WIDTH, Preferences.FENETRE_HEIGHT, false).start();
	}
}

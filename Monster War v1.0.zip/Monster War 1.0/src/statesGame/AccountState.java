package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

import autre.Preferences;
import ecranCreationSelectionCompte.CreationPersonnage;

public class AccountState extends BasicGameState {
	// Attributs
	public static final int ID = Preferences.FENETRE_CREATION_CHARGEMENT_COMPTE;
	private StateBasedGame game;
	private CreationPersonnage imageCreation;

	// Constructeur
	public AccountState() {
		super();
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.game = game;
		this.imageCreation = new CreationPersonnage(container);
	}

	public void render(GameContainer container, StateBasedGame game, Graphics graph) throws SlickException {
		this.imageCreation.render(container, graph);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
		this.imageCreation.update(delta);
		if (this.imageCreation.isCreationReussi()) {
			game.enterState(MainGameState.ID);
			// TODO envoyer le perso dans MainGameState
		}
	}

	// Methodes
	public int getID() {
		return ID;
	}

	public void keyReleased(int key, char c) {
		switch (key) {
		case Input.KEY_ENTER:
			game.enterState(MainGameState.ID);
			break;
		}
	}

	@Override
	public void mouseClicked(int button, int x, int y, int clickCount) {
		this.imageCreation.updateClick(x, y);
	}
}
package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

import autre.Preferences;

public class BattleGameState extends BasicGameState {
	// Attributs
	public static final int ID = Preferences.FENETRE_COMBAT;
	private StateBasedGame game;
	private Image background;

	// Constructeur
	public BattleGameState() {
		super();
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.game = game;
		this.background = new Image(Preferences.DOSSIER_BACKGROUNDS + "battle.png");

	}

	public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException {
		background.draw(0, 0, container.getWidth(), container.getHeight());
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
	}

	// Methodes
	public void keyPressed(int key, char c) {
		game.enterState(MainGameState.ID);
	}

	public int getID() {
		return ID;
	}
}
package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Music;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

import autre.Controller;
import autre.Preferences;
import ecranMap.Camera;
import ecranMap.Hud;
import ecranMap.Map;
import ecranMap.Personnage;
import ecranMap.Trigger;

public class MainGameState extends BasicGameState {

	// Attributs
	public static final int ID = Preferences.FENETRE_MAP;
	private GameContainer container;
	private Map map;
	private Personnage hero;
	private Hud hud;
	private Camera camera;
	private Music backgroundMusic;
	private Trigger triggers;
	private Controller controler;

	// Constructeur
	public MainGameState() {
		super();
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.container = container;

		this.backgroundMusic = new Music(Preferences.MUSIQUE_FOND);
		this.backgroundMusic.loop();

		this.map = new Map(Preferences.DOSSIER_MAPS + "route1.tmx");
		this.hero = new Personnage();
		this.hero.newPersonnageRandom();
		this.hud = new Hud(hero);
		this.triggers = new Trigger(map, hero);
		this.camera = new Camera(hero);

		this.controler = new Controller(hero);
		this.controler.setInput(container.getInput());
		this.container.getInput().addKeyListener(controler);
		this.container.getInput().addMouseListener(controler);
	}

	public void render(GameContainer container, StateBasedGame game, Graphics graph) throws SlickException {
		this.camera.placer(container, graph);
		this.map.renderBackground();
		this.hero.render(graph);
		this.map.renderForeground();
		this.hud.render(graph);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
		this.controler.update();
		this.triggers.update();
		this.hero.update(delta);
		this.camera.update(container);
		if (Math.random() < 0.001 && hero.isMoving()) {
			game.enterState(BattleGameState.ID);
		}
	}

	// Methode
	public int getID() {
		return ID;
	}
}
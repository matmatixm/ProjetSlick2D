
########################################################################################################################

Si le jeu ne se lance pas avec Eclipse: 
Erreur : Exception in thread "main" java.lang.UnsatisfiedLinkError: no lwjgl in java.library.path

-Clique droit sur game/Main.java
-Properties
-run/debug settings
-double cliquer sur le main
-Arguments
-entrer la phrase ci dessous dans la case "VM arguments" (sans les "")
	"-Djava.library.path=libs/natives"

########################################################################################################################


A faire :
- Debugguer maMap.tmx
- regarder les tasks.
- En cours Les menus pour demarrer et sauvegarder et charger.
- Actuellement le perso se creer avec les bonnes stats (visible dans le dossier sauvegarde) mais impossible de recuperer quoi que ce soit.
- Prochaine etape les phases de combat.

########################################################################################################################

Si apres creation d'une map on a cette erreur : 

Carte : "Failed to parse tilemap at org.newdawn.slick.tiled.TiledMap"

Si vous avez cette erreur quand vous ajouter un calque d'objet, cela viens en fait de votre version de Tiled qui n'enregistre
plus la taille de la carte dans ce calque.  Vous pouvez éditer votre carte avec un éditeur texte, rechercher cette balise :

<objectgroup name="...">

Et ajouter les attributs width et height comme ceci :

<objectgroup name="..." width="XXX" height="YYY">

Ou XXX et YYY est respectivement la largeur et la hauteur de votre carte en tuile.

########################################################################################################################

Attention Actuellement le chargement ne marche pas il n'a pas ete implemente. 
Il faut donc absolument creer un ne perso.

########################################################################################################################

Outils Pratiques :

Editeur Image en Ligne : 	https://pixlr.com/editor/
Bibliotheque Image cool :	https://fr.pngtree.com/
Bibliotheque Tiles :			https://vxresource.wordpress.com/category/resources/tilesets/

########################################################################################################################

Futur Infos

########################################################################################################################
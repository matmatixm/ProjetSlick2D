package ecranCreationSelectionCompte;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import aUtils.Preferences;

public class CompteurPointsStats {
	// Tailles
	private float xI;
	private float yI;
	private float widthI;
	private float heightI;

	// Tailles
	private float xS;
	private float yS;
	private float widthS;
	private float heightS;

	// Autre
	private int nbPoints;
	private final Color couleurTexte = new Color(0, 160, 180);
	private Image cadrePoints;

	// Constructeur
	public CompteurPointsStats(float x, float y, float width, float height, int nbPoints, GameContainer gc)
			throws SlickException {
		super();

		// Tailles
		this.widthS = gc.getDefaultFont().getWidth("Points : 000");
		this.heightS = gc.getDefaultFont().getHeight("Points : 000");
		this.widthI = width;
		this.heightI = height;

		// Position
		this.xI = x;
		this.yI = y;
		this.xS = xI + widthI / 2 - widthS / 2;
		this.yS = yI + heightI / 2 - heightS / 2;

		// Points
		this.nbPoints = nbPoints;
		cadrePoints = new Image(Preferences.DOSSIER_HUDS + "carreTransparent.png").getScaledCopy((int) widthI,
				(int) heightI);
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		graph.drawImage(cadrePoints, (int) xI, (int) yI);
		graph.setColor(this.couleurTexte);
		graph.drawString(String.format("Points : %02d", this.nbPoints), (int) xS, (int) yS);
	}

	public void update(int delta) {
	}

	public void updateClick(int nbPoints) {
		this.nbPoints = nbPoints;
	}
}

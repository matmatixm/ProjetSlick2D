package ecranCreationSelectionCompte;

import org.newdawn.slick.Color;
import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

import aUtils.Preferences;

public class LigneStat {
	// Autre
	public final static float espacementBoutons = 10;
	public SelectionStats classeMere;

	// Bouttons
	private float xP;
	private float xM;
	private float xV;
	private float yAll;
	private float widthAll;
	private float heightAll;
	private boolean plusSelected = false;
	private boolean moinsSelected = false;
	private float tempPlus = 0;
	private float tempMoins = 0;

	// Stat Value
	private float xVal;
	private float yVal;
	private String valStat;

	// Stat Texte
	private float xText;
	private float yText;
	private String texte;
	private Font font;

	// Image
	private Image plus;
	private Image plusS;
	private Image moins;
	private Image moinsS;

	// Couleur
	private final Color couleurTexte = new Color(3, 39, 102);

	// Constructeur
	public LigneStat(GameContainer gc, SelectionStats classeMere, String texte, float x, float y, float widthLigne,
			float heightLigne, Image plus, Image plusS, Image moins, Image moinsS, Font font) {
		super();

		// Autre
		this.classeMere = classeMere;

		// Taille Bouttons
		this.widthAll = plus.getWidth();
		this.heightAll = plus.getHeight();

		// Bouttons Position
		this.xM = x;
		this.xV = xM + widthAll + espacementBoutons;
		this.xP = xV + widthAll + espacementBoutons;
		this.yAll = y;

		// Init Temps + Selected
		this.plusSelected = false;
		this.moinsSelected = false;
		this.tempPlus = 0;
		this.tempMoins = 0;

		// Stat Texte
		this.font = font;
		this.xVal = xV + widthAll / 2 - this.font.getWidth("00") / 2 - 2;
		this.yVal = yAll + heightAll / 2 - this.font.getHeight("00") / 2 - 2;

		// Position Texte
		this.xText = xP + widthAll + espacementBoutons;
		this.yText = yVal;

		// Init Image
		this.plus = plus;
		this.plusS = plusS;
		this.moins = moins;
		this.moinsS = moinsS;

		// Init des String
		this.valStat = "00";
		this.texte = texte;
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		if (!plusSelected)
			graph.drawImage(plus, xP, yAll);
		else
			graph.drawImage(plusS, xP, yAll);

		if (!moinsSelected)
			graph.drawImage(moins, xM, yAll);
		else
			graph.drawImage(moinsS, xM, yAll);

		graph.setColor(couleurTexte);
		graph.drawString(valStat, xVal, yVal);
		graph.drawString(texte, xText, yText);
	}

	public void update(int delta) {
		if (plusSelected)
			tempPlus += delta;
		else if (moinsSelected)
			tempMoins += delta;

		if (tempPlus >= Preferences.TIME_CLICK_BUTTON) {
			tempPlus = 0;
			plusSelected = false;
		} else if (tempMoins >= Preferences.TIME_CLICK_BUTTON) {
			tempMoins = 0;
			moinsSelected = false;
		}
	}

	public void updateClick(int x, int y, int nbPointsDispo) {
		int newVal = 0;
		if (y >= yAll && y <= yAll + heightAll) {
			if (x >= xM && x <= xM + widthAll) {
				moinsSelected = true;
				newVal = Integer.parseInt(valStat) - 1;
				if (newVal >= 0) {
					valStat = String.format("%02d", newVal);
					classeMere.setNbrePointsTotalPlus();
				}
			} else if (x >= xP && x <= xP + widthAll) {
				plusSelected = true;
				newVal = Integer.parseInt(valStat) + 1;
				if (nbPointsDispo > 0) {
					valStat = String.format("%02d", newVal);
					classeMere.setNbrePointsTotalMoins();
				}
			}
		}
	}

	public int getValeur() {
		return Integer.parseInt(valStat);
	}
}

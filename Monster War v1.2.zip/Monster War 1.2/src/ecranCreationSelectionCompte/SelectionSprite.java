package ecranCreationSelectionCompte;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.newdawn.slick.Animation;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

import aUtils.Preferences;

public class SelectionSprite {
	// Image Fleches
	private float xFG;
	private float xFD;
	private float yF;
	private float widthF;
	private float heightF;
	private boolean flecheDselected;
	private boolean flecheGselected;
	private float tempFlecheD;
	private float tempFlecheG;

	// Image Sprite
	private float xS;
	private float yS;
	private float widthS;
	private float heightS;
	private int spriteNum;

	// Images
	private List<Animation> listeSprites = new ArrayList<>();
	private Image nextG;
	private Image nextGselected;
	private Image nextD;
	private Image nextDselected;

	// Constructeur
	public SelectionSprite(float x, float y, float width, float height, GameContainer gc) throws SlickException {
		super();

		// Taille Composants
		this.heightS = height;
		this.heightF = width / 9;
		this.widthS = width / 3;
		this.widthF = width / 10;

		// Positions Composants
		this.xS = x + width / 2 - widthS / 2;
		this.xFG = x + (xS - x) / 2 - widthF / 2;
		this.xFD = xS + widthS + (xS - x) / 2 - widthF / 2;
		this.yS = y - height * 0.1f;
		this.yF = y + heightS / 2 - heightF / 2;

		// Init temps et selection
		this.flecheDselected = false;
		this.flecheGselected = false;
		this.tempFlecheD = 0;
		this.tempFlecheG = 0;
		this.spriteNum = 0;

		// Charger les sprites
		chargerListeSprites();

		// Images
		this.nextG = new Image(Preferences.DOSSIER_HUDS + "flecheGauche.png").getScaledCopy((int) widthF,
				(int) heightF);
		this.nextGselected = new Image(Preferences.DOSSIER_HUDS + "flecheGaucheClique.png").getScaledCopy((int) widthF,
				(int) heightF);
		this.nextD = new Image(Preferences.DOSSIER_HUDS + "flecheDroite.png").getScaledCopy((int) widthF,
				(int) heightF);
		this.nextDselected = new Image(Preferences.DOSSIER_HUDS + "flecheDroiteClique.png").getScaledCopy((int) widthF,
				(int) heightF);
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		if (flecheGselected)
			graph.drawImage(nextGselected, (int) xFG, (int) yF);
		else
			graph.drawImage(nextG, (int) xFG, (int) yF);

		graph.drawAnimation(listeSprites.get(spriteNum), (int) xS, (int) yS);

		if (flecheDselected)
			graph.drawImage(nextDselected, (int) xFD, (int) yF);
		else
			graph.drawImage(nextD, (int) xFD, (int) yF);
	}

	public void update(int delta) {
		if (flecheGselected)
			tempFlecheG += delta;
		else if (flecheDselected)
			tempFlecheD += delta;

		if (tempFlecheG >= Preferences.TIME_CLICK_BUTTON) {
			tempFlecheG = 0;
			flecheGselected = false;
		} else if (tempFlecheD >= Preferences.TIME_CLICK_BUTTON) {
			tempFlecheD = 0;
			flecheDselected = false;
		}
	}

	public void updateClick(int x, int y) {
		if (y >= yF && y <= yF + heightF) {
			if (x >= xFG && x <= xFG + widthF) {
				flecheGselected = true;
				spriteNum = (spriteNum + 1) % listeSprites.size();
			} else if (x >= xFD && x <= xFD + widthF) {
				flecheDselected = true;
				spriteNum = (spriteNum - 1);
				if (spriteNum < 0)
					spriteNum = listeSprites.size() - 1;
			}
		}
	}

	private void chargerListeSprites() throws SlickException {
		// TODO recuperer liste predefinie et non tous le dossier (bad security)
		File repertoire = new File(Preferences.DOSSIER_SPRITES_MAP + "spriteBase");
		for (String s : repertoire.list())
			listeSprites.add(loadAnimation(s));
	}

	private Animation loadAnimation(String s) throws SlickException {
		SpriteSheet spriteSheet = new SpriteSheet(Preferences.DOSSIER_SPRITES_MAP + s, 64, 64);
		Animation animation = new Animation();
		for (int x = 1; x < 9; x++)
			animation.addFrame(spriteSheet.getSprite(x, 2).getScaledCopy((int) widthS, (int) heightS), 100);
		return animation;
	}

	public int recuperationSprite() {
		return this.spriteNum;
	}
}

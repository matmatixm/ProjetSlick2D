package ecranCreationSelectionCompte;

import java.util.ArrayList;
import java.util.List;

import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import aUtils.Preferences;

public class SelectionStats {
	// Tailles
	private float widthImage;
	private float heightImage;
	private float widthLigne;
	private float heightLigne;

	// Infos Lignes
	private float decalageLigne;
	private final int nbLigne = 5;
	private final float espacementLigne = 10;

	// Images
	private int nbrePointsTotal = 20;
	private Image plus;
	private Image plusS;
	private Image moins;
	private Image moinsS;
	private List<LigneStat> listeStat = new ArrayList<>();

	// compteurPoints
	private float xCP;
	private float yCP;
	private float widthCP;
	private float heightCP;
	private CompteurPointsStats compteurPoints;

	// Constructeur
	public SelectionStats(float x, float y, float width, float height, Font font, GameContainer gc)
			throws SlickException {
		super();
		// Taille Ligne
		this.decalageLigne = width / 10;
		this.widthLigne = width;
		this.heightLigne = (height - (espacementLigne * (nbLigne - 1))) / nbLigne;

		// Taille Image
		this.widthImage = widthLigne - (((LigneStat.espacementBoutons * 3) * 0.33f) / 3);
		this.heightImage = heightLigne;
		if (widthImage > heightImage)
			widthImage = heightImage;
		else
			heightImage = widthImage;

		// Load Image
		this.plus = new Image(Preferences.DOSSIER_HUDS + "bouttonPlus.png").getScaledCopy((int) widthImage,
				(int) heightImage);
		this.plusS = new Image(Preferences.DOSSIER_HUDS + "bouttonPlusClique.png").getScaledCopy((int) widthImage,
				(int) heightImage);
		this.moins = new Image(Preferences.DOSSIER_HUDS + "bouttonMoins.png").getScaledCopy((int) widthImage,
				(int) heightImage);
		this.moinsS = new Image(Preferences.DOSSIER_HUDS + "bouttonMoinsClique.png").getScaledCopy((int) widthImage,
				(int) heightImage);

		// Liste Stats
		listeStat.add(new LigneStat(gc, this, "Force", x + decalageLigne, y, widthLigne, heightLigne, plus, plusS,
				moins, moinsS, font));
		listeStat.add(new LigneStat(gc, this, "Intelligence", x + decalageLigne, y + (heightLigne + espacementLigne),
				widthLigne, heightLigne, plus, plusS, moins, moinsS, font));
		listeStat.add(new LigneStat(gc, this, "Constitution", x + decalageLigne,
				y + (heightLigne + espacementLigne) * 2, widthLigne, heightLigne, plus, plusS, moins, moinsS, font));
		listeStat.add(new LigneStat(gc, this, "Esprit", x + decalageLigne, y + (heightLigne + espacementLigne) * 3,
				widthLigne, heightLigne, plus, plusS, moins, moinsS, font));
		listeStat.add(new LigneStat(gc, this, "Agilite", x + decalageLigne, y + (heightLigne + espacementLigne) * 4,
				widthLigne, heightLigne, plus, plusS, moins, moinsS, font));

		// Compteur de Points
		this.xCP = x + width * 0.7f;
		this.yCP = y + height * 0.85f;
		this.widthCP = (x + width) - xCP;
		this.heightCP = (y + height) - yCP;
		compteurPoints = new CompteurPointsStats(xCP, yCP, widthCP, heightCP, nbrePointsTotal, gc);
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		for (LigneStat lS : listeStat)
			lS.render(container, graph);

		compteurPoints.render(container, graph);
	}

	public void update(int delta) {
		for (LigneStat lS : listeStat)
			lS.update(delta);
		compteurPoints.update(delta);
	}

	public void updateClick(int x, int y) {
		for (LigneStat lS : listeStat)
			lS.updateClick(x, y, nbrePointsTotal);
		compteurPoints.updateClick(nbrePointsTotal);
	}

	public int recuperationForce() {
		return listeStat.get(0).getValeur();
	}

	public int recuperationIntel() {
		return listeStat.get(1).getValeur();
	}

	public int recuperationConst() {
		return listeStat.get(2).getValeur();
	}

	public int recuperationEsprit() {
		return listeStat.get(3).getValeur();
	}

	public int recuperationAgi() {
		return listeStat.get(4).getValeur();
	}

	public void setNbrePointsTotalPlus() {
		this.nbrePointsTotal++;
	}

	public void setNbrePointsTotalMoins() {
		this.nbrePointsTotal--;
	}

	public int getNbrePointsTotal() {
		return nbrePointsTotal;
	}
}
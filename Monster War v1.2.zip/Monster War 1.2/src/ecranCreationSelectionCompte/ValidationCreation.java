package ecranCreationSelectionCompte;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import aUtils.Preferences;

public class ValidationCreation {
	// Attributs
	private float x;
	private float y;
	private float width;
	private float height;
	private Image next;
	private Image nextSelected;
	private boolean selected = false;
	private float time = 0;
	private CreationPersonnage classeMere;

	// Constructeur
	public ValidationCreation(CreationPersonnage classeMere, float x, float y, float width, float height,
			GameContainer gc) throws SlickException {
		super();

		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.classeMere = classeMere;
		this.next = new Image(Preferences.DOSSIER_HUDS + "flecheNext.png").getScaledCopy((int) width, (int) height);
		this.nextSelected = new Image(Preferences.DOSSIER_HUDS + "flecheNextSelected.png").getScaledCopy((int) width,
				(int) height);
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		if (selected)
			graph.drawImage(nextSelected, (int) x, (int) y);
		else
			graph.drawImage(next, (int) x, (int) y);

	}

	public void update(int delta) {
		if (selected)
			time += delta;

		if (time >= Preferences.TIME_CLICK_BUTTON) {
			time = 0;
			selected = false;
		}
	}

	public void updateClick(int x, int y) {
		if (x >= this.x && x <= this.x + width && y >= this.y && y <= this.y + height) {
			this.selected = true;
			this.classeMere.valider();
		}
	}
}

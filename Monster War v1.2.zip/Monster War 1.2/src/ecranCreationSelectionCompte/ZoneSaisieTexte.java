package ecranCreationSelectionCompte;

import org.newdawn.slick.Color;
import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.gui.TextField;

import aUtils.Preferences;

public class ZoneSaisieTexte {
	// Saisie Texte
	private float xText;
	private float yText;
	private float widthText;
	private float heightText;
	private TextField zoneSaisie;
	private boolean initPseudo = false;

	// Bulle
	private float xBulle;
	private float yBulle;
	private float widthBulle;
	private float heightBulle;
	private Image imageBulle;

	// Font
	private Font font;
	private float hauteurMaxFont;
	private float largeurMaxFont;
	private final int caractereMax = 15;

	// Couleur
	private final Color colorTexteField = new Color(196, 227, 245);

	// Constructeur
	public ZoneSaisieTexte(float x, float y, float width, float height, Font font, GameContainer gc)
			throws SlickException {
		super();

		// Font
		this.font = font;
		this.hauteurMaxFont = font.getHeight("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
		this.largeurMaxFont = font.getWidth("01234567890123456789  ");

		// Difference entre Texte et Bulle
		float diffY = 0.025f * width;

		// Texte
		this.heightText = hauteurMaxFont + 2;
		this.widthText = ((largeurMaxFont / 20) * caractereMax);
		this.xText = x + width / 2 - widthText / 2;
		this.yText = y + height / 2 - heightText / 2 - diffY;
		this.zoneSaisie = new TextField(gc, this.font, (int) xText, (int) yText, (int) widthText, (int) heightText);
		this.zoneSaisie.setCursorVisible(true);
		this.zoneSaisie.setText("    Pseudo");

		// TODO limite le nombre de caractere a caractereMax de zoneSaisie

		// Images
		imageBulle = new Image(Preferences.DOSSIER_HUDS + "nuage.png");
		float coeffScaleX = width / imageBulle.getWidth();
		float coeffScaleY = height / imageBulle.getHeight();
		if (coeffScaleX > coeffScaleY)
			imageBulle = imageBulle.getScaledCopy(coeffScaleY);
		else
			imageBulle = imageBulle.getScaledCopy(coeffScaleX);

		// Position
		this.widthBulle = imageBulle.getWidth();
		this.heightBulle = imageBulle.getHeight();
		this.xBulle = x + width / 2 - widthBulle / 2;
		this.yBulle = y;
	}

	// Methodes
	public void render(GameContainer container, Graphics graph) {
		graph.drawImage(imageBulle, (int) xBulle, (int) yBulle);
		graph.setColor(Color.white);
		zoneSaisie.setBorderColor(null);
		zoneSaisie.setTextColor(Color.red);
		zoneSaisie.setBackgroundColor(colorTexteField);
		zoneSaisie.render(container, graph);
	}

	public void update(int delta) {
	}

	public void updateClick(int x, int y) {
		if (!initPseudo) {
			if (x >= xBulle && x <= xBulle + widthBulle && y >= yBulle && y <= yBulle + heightBulle) {
				initPseudo = true;
				this.zoneSaisie.setText("");
			}
		}
	}

	public String recuperationNom() {
		return this.zoneSaisie.getText();
	}
}

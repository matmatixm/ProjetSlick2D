package ecranMap;

import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import aUtils.Preferences;

public class Hud {
	// Attributs
	private Image playerbars;
	private Personnage joueur;

	private static final int hudX = 10;
	private static final int hudY = 10;

	private static final int barX = 84 + hudX;
	private static final int barY = 4 + hudY;

	private static final int barWidth = 80;
	private static final int barHeight = 16;
	private static final int barEcart = 20;

	// Constructeur
	public Hud(Personnage joueur) throws SlickException {
		this.playerbars = new Image(Preferences.DOSSIER_HUDS + "barre.png");
		this.joueur = joueur;
	}

	// Methodes
	public void render(Graphics graph) {
		graph.resetTransform();
		remplirBarreVie(joueur.getVieActuelle() / joueur.getVieMax(), graph);
		remplirBarreMana(joueur.getManaActuelle() / joueur.getManaMax(), graph);
		remplirBarreExp(joueur.getExpActuelle() / joueur.getExpMax(), graph);
		graph.drawImage(this.playerbars, hudX, hudY);
	}

	private void remplirBarreVie(float pourcentage, Graphics graph) {
		graph.setColor(new Color(255, 0, 0));
		graph.fillRect(barX, barY, pourcentage * barWidth, barHeight);
	}

	private void remplirBarreMana(float pourcentage, Graphics graph) {
		graph.setColor(new Color(0, 0, 255));
		graph.fillRect(barX, barY + barEcart, pourcentage * barWidth, barHeight);
	}

	private void remplirBarreExp(float pourcentage, Graphics graph) {
		graph.setColor(new Color(0, 255, 0));
		graph.fillRect(barX, barY + barEcart * 2, pourcentage * barWidth, barHeight);
	}
}
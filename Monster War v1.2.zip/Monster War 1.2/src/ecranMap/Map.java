package ecranMap;

import org.newdawn.slick.Color;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.tiled.TiledMap;

import com.fasterxml.jackson.annotation.JsonIgnore;

import aUtils.Preferences;

public class Map {
	// Attributs
	private String fileMap;
	private int nbRenduBackground;
	private int nbRenduForeground;
	@JsonIgnore
	private TiledMap tiledMap;

	// Constructeur
	public Map() {
		super();
	}

	public Map(String fileMap) {
		this.fileMap = fileMap;
		try {
			this.tiledMap = new TiledMap(fileMap);
		} catch (SlickException e) {
			e.printStackTrace();
		}
		nbRenduBackground = 3;
		nbRenduForeground = 2;
	}

	public Map(String fileMap, int calqueBG, int calqueFG) {
		this.fileMap = fileMap;
		try {
			this.tiledMap = new TiledMap(fileMap);
		} catch (SlickException e) {
			e.printStackTrace();
		}
		nbRenduBackground = calqueBG;
		nbRenduForeground = calqueFG;
	}

	// Methodes
	public void renderBackground() {
		for (int cpt = 0; cpt < nbRenduBackground; cpt++)
			this.tiledMap.render(0, 0, cpt);
	}

	public void renderForeground() {
		for (int cpt = 0; cpt < nbRenduForeground; cpt++)
			this.tiledMap.render(0, 0, nbRenduBackground + cpt);
	}

	public boolean isCollision(float x, float y) {
		int tileW = this.tiledMap.getTileWidth();
		int tileH = this.tiledMap.getTileHeight();
		int logicLayer = this.tiledMap.getLayerIndex(Preferences.CALQUE_LOGIC);
		Image tile = this.tiledMap.getTileImage((int) x / tileW, (int) y / tileH, logicLayer);
		boolean collision = tile != null;
		if (collision) {
			Color color = tile.getColor((int) x % tileW, (int) y % tileH);
			collision = color.getAlpha() > 0;
		}
		return collision;
	}

	public void changeMap(String nomMap) throws SlickException {
		this.tiledMap = new TiledMap(nomMap);
	}

	// Getters Speciaux
	public int getObjectCount() {
		return this.tiledMap.getObjectCount(0);
	}

	public String getObjectType(int objectID) {
		return this.tiledMap.getObjectType(0, objectID);
	}

	public float getObjectX(int objectID) {
		return this.tiledMap.getObjectX(0, objectID);
	}

	public float getObjectY(int objectID) {
		return this.tiledMap.getObjectY(0, objectID);
	}

	public float getObjectWidth(int objectID) {
		return this.tiledMap.getObjectWidth(0, objectID);
	}

	public float getObjectHeight(int objectID) {
		return this.tiledMap.getObjectHeight(0, objectID);
	}

	public String getObjectProperty(int objectID, String propertyName, String def) {
		return this.tiledMap.getObjectProperty(0, objectID, propertyName, def);
	}

	// Getters
	public String getFileMap() {
		return fileMap;
	}

	public int getNbRenduBackground() {
		return nbRenduBackground;
	}

	public int getNbRenduForeground() {
		return nbRenduForeground;
	}

	public TiledMap getTiledMap() {
		return tiledMap;
	}

	// Setters
	public void setFileMap(String fileMap) {
		this.fileMap = fileMap;
	}

	public void setNbRenduBackground(int nbRenduBackground) {
		this.nbRenduBackground = nbRenduBackground;
	}

	public void setNbRenduForeground(int nbRenduForeground) {
		this.nbRenduForeground = nbRenduForeground;
	}

	public void setTiledMap(TiledMap tiledMap) {
		this.tiledMap = tiledMap;
	}
}
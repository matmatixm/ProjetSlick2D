package main;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;

import aUtils.Preferences;
import utilsGameStates.ListeStates;

public class Main {

	public static void main(String[] args) throws SlickException {
		if (Preferences.FENETRE_WIDTH < 500 || Preferences.FENETRE_HEIGHT < 400) {
			System.out.println("Resolution trop faible");
			System.exit(0);
		}
		new AppGameContainer(new ListeStates(), Preferences.FENETRE_WIDTH, Preferences.FENETRE_HEIGHT, false).start();
	}
}

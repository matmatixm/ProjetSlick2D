package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

import ecranCreationSelectionCompte.CreationPersonnage;
import ecranMap.Personnage;
import utilsGameStates.DefaultState;
import utilsGameStates.GameData;
import utilsGameStates.ListeStates;
import utilsGameStates.StatesID;

public class AccountGameState extends DefaultState<AccountGameState> {
	// Attributs
	public static final int ID = StatesID.FENETRE_CREATION_CHARGEMENT_COMPTE.getID();
	private StateBasedGame game;
	private CreationPersonnage imageCreation;

	// Constructeur
	public AccountGameState(ListeStates listeStates) {
		super(listeStates);
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.game = game;
		this.imageCreation = new CreationPersonnage(container);
	}

	public void render(GameContainer container, StateBasedGame game, Graphics graph) throws SlickException {
		this.imageCreation.render(container, graph);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
		this.imageCreation.update(delta);
		if (this.imageCreation.isCreationReussi()) {
			sendPersonnage(this.imageCreation.getPersonnage());
			game.enterState(MainGameState.ID);
		}
	}

	// Methodes
	private void sendPersonnage(Personnage p) {
		GameData g = new GameData(p);
		this.setGameData(g);
	}

	public int getID() {
		return ID;
	}

	public void keyReleased(int key, char c) {
		switch (key) {
		case Input.KEY_ENTER:
			game.enterState(MainGameState.ID);
			break;
		}
	}

	public void mouseClicked(int button, int x, int y, int clickCount) {
		this.imageCreation.updateClick(x, y);
	}
}
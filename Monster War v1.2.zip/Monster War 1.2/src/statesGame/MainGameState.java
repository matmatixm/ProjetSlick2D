package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Music;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

import aUtils.Preferences;
import ecranMap.Camera;
import ecranMap.Controller;
import ecranMap.Hud;
import ecranMap.Map;
import ecranMap.Personnage;
import ecranMap.Trigger;
import utilsGameStates.DefaultState;
import utilsGameStates.ListeStates;
import utilsGameStates.StatesID;

public class MainGameState extends DefaultState<MainGameState> {

	// Attributs
	public static final int ID = StatesID.FENETRE_MAP.getID();
	private GameContainer container;
	private Map map;
	private Personnage hero;
	private Hud hud;
	private Camera camera;
	private Music backgroundMusic;
	private Trigger triggers;
	private Controller controler;

	// Constructeur
	public MainGameState(ListeStates listeStates) {
		super(listeStates);
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.container = container;

		this.backgroundMusic = new Music(Preferences.MUSIQUE_FOND);
		this.backgroundMusic.loop();

		if (Preferences.MAP_BOOL_TEST)
			this.map = new Map(Preferences.DOSSIER_MAPS + Preferences.MAP_TEST,Preferences.MAP_CALQUE_BACKGROUND,Preferences.MAP_CALQUE_FOREGROUND);
		else
			this.map = new Map(Preferences.DOSSIER_MAPS + "route1.tmx");
		this.hero = new Personnage();
		this.hero.newPersonnageRandom();
		this.hud = new Hud(hero);
		this.triggers = new Trigger(map, hero);
		this.camera = new Camera(hero);

		this.controler = new Controller(hero);
		this.controler.setInput(container.getInput());
		this.container.getInput().addKeyListener(controler);
		this.container.getInput().addMouseListener(controler);
	}

	public void render(GameContainer container, StateBasedGame game, Graphics graph) throws SlickException {
		this.camera.placer(container, graph);
		this.map.renderBackground();
		this.hero.render(graph);
		this.map.renderForeground();
		this.hud.render(graph);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
		this.controler.update();
		this.triggers.update();
		this.hero.update(delta);
		this.camera.update(container);
		if (Math.random() < 0.001 && hero.isMoving()) {
			game.enterState(BattleGameState.ID);
		}
	}

	public void enter(GameContainer container, StateBasedGame game) throws SlickException {
		super.enter(container, game);
		if (!Preferences.MAP_BOOL_TEST)
			this.hero = receivePersonnage();
	}

	// Methode
	public Personnage receivePersonnage() {
		return this.getGameData().getPersonnage();
	}

	public int getID() {
		return ID;
	}
}
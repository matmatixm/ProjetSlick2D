package statesGame;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

import ecranTitre.EcranTitre;
import utilsGameStates.DefaultState;
import utilsGameStates.ListeStates;
import utilsGameStates.StatesID;

public class TitleScreenGameState extends DefaultState<TitleScreenGameState> {
	// Attributs
	public static final int ID = StatesID.FENETRE_ECRAN_TITRE.getID();
	private StateBasedGame game;
	private EcranTitre ecranTitre;

	// Constructeur
	public TitleScreenGameState(ListeStates listeStates) {
		super(listeStates);
	}

	// 3 Fonctions Principales
	public void init(GameContainer container, StateBasedGame game) throws SlickException {
		this.game = game;
		this.ecranTitre = new EcranTitre();
	}

	public void render(GameContainer container, StateBasedGame game, Graphics graph) throws SlickException {
		ecranTitre.render(container, graph);
	}

	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
	}

	// Methodes
	public int getID() {
		return ID;
	}

	public void keyPressed(int key, char c) {
		game.enterState(AccountGameState.ID);
	}

	public void mouseClicked(int button, int x, int y, int clickCount) {
		game.enterState(AccountGameState.ID);
	}
}
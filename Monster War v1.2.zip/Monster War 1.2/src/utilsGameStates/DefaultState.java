package utilsGameStates;

import org.newdawn.slick.state.BasicGameState;

public abstract class DefaultState<T> extends BasicGameState {
	// Attributs
	private ListeStates listeStates;

	// Constructeur
	public DefaultState(ListeStates listeStates) {
		super();
		this.listeStates = listeStates;
	}

	// Getters
	public GameData getGameData() {
		return listeStates.getGameData();
	}

	// Setters
	public void setGameData(GameData gameData) {
		listeStates.setGameData(gameData);
	}
}

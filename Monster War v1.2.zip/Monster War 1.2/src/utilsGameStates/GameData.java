package utilsGameStates;

import ecranMap.Personnage;

public class GameData {
	// Attributs
	private Personnage personnage;

	// Constructeur
	public GameData(GameData g) {
		this.personnage = g.personnage;
	}

	public GameData(Personnage personnage) {
		this.personnage = personnage;
	}

	// Getters
	public Personnage getPersonnage() {
		return personnage;
	}
}

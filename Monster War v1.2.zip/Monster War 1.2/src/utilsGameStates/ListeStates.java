package utilsGameStates;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

import aUtils.Preferences;
import statesGame.AccountGameState;
import statesGame.BattleGameState;
import statesGame.MainGameState;
import statesGame.TitleScreenGameState;

public class ListeStates extends StateBasedGame {
	// Attributs
	private GameData gameData = null;

	// Constructeur
	public ListeStates() {
		super(Preferences.NOM_JEU);
	}

	// Methodes
	public void initStatesList(GameContainer container) throws SlickException {
		container.setIcon(Preferences.LIEN_ICONE_FENETRE);
		container.setShowFPS(false);

		addState(new TitleScreenGameState(this));
		addState(new AccountGameState(this));
		addState(new MainGameState(this));
		addState(new BattleGameState(this));
	}

	// Getters
	public GameData getGameData() {
		return gameData;
	}

	// Setters
	public void setGameData(GameData gameData) {
		this.gameData = new GameData(gameData);
	}
}

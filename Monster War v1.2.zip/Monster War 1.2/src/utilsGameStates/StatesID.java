package utilsGameStates;

public enum StatesID {
	FENETRE_ECRAN_TITRE(0), FENETRE_CREATION_CHARGEMENT_COMPTE(1), FENETRE_MAP(2), FENETRE_COMBAT(3);

	// Attributs
	private int id;

	// Constructeur
	StatesID(int id) {
		this.id = id;
	}

	// Methodes
	public int getID() {
		return id;
	}
}
